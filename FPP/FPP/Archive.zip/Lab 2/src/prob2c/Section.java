package prob2c;

import java.util.ArrayList;
import java.util.List;

public class Section {

	private List<Student> studentList = new ArrayList<>();
	
	public Section(Student student) {
		studentList.add(student);
	}
	
}
