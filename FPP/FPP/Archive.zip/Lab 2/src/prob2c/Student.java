package prob2c;

import java.util.ArrayList;
import java.util.List;

public class Student {

	private List<Section> sectionList = new ArrayList<>();
	
	public Student() {
		
	}
	public Student(Section section) {
		sectionList.add(section);
	}
}
