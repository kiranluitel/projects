package projectmanagementsystem;

import java.util.ArrayList;
import java.util.List;

public class Project {
	List<Feature> featureList = new ArrayList<Feature>();
	List<Release> releaseList = new ArrayList<Release>();
	
	
	public List<Feature> getFeatureList() {
		return featureList;
	}
	public void setFeatureList(List<Feature> featureList) {
		this.featureList = featureList;
	}
	public List<Release> getReleaseList() {
		return releaseList;
	}
	public void setReleaseList(List<Release> releaseList) {
		this.releaseList = releaseList;
	}
}
