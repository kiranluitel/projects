package projectmanagementsystem;

import java.util.*;
public class Release {
	private List<Sprint> sprintList = new ArrayList<>();

	public List<Sprint> getSprintList() {
		return sprintList;
	}

	
	
}
