package projectmanagementsystem;

import java.util.*;

public class Sprint {
	private List<Feature> featureList = new ArrayList<>();

	public List<Feature> getFeatureList() {
		return featureList;
	}


	
	
}
