package projectmanagementsystem;

public class ProjectManager {
	private Project project = new Project();
	
	public void addReleaseFeature(Release r, Feature f) {

	}
}
