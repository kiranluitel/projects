package prob2a;

public class GradeReport {
	
	private Student student;
	
	public GradeReport(Student student) {
		this.student = student;
	}

}
