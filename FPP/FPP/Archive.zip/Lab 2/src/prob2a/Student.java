package prob2a;

public class Student {

	private GradeReport gradeReport;
	private String name;
	
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public Student() {
		gradeReport = new GradeReport(this);
	}
}
