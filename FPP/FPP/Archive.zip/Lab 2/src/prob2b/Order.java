package prob2b;

import java.util.*;
public class Order {
	
	List<OrderLine> orderLineList = new ArrayList<>();
	
	public Order(OrderLine orderLine) {
		orderLineList.add(orderLine);
	}
	
}
