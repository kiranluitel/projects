package prob2b;

public class OrderLine {

	private Order order;
	
	public OrderLine() {
		order = new Order(this);
	}
	public static void main(String[] args) {
		Order order = new Order(new OrderLine());
	}
}
