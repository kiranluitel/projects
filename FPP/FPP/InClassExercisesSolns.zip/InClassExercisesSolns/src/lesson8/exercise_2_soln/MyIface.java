package lesson8.exercise_2_soln;

public interface MyIface {
	int produce();
}
